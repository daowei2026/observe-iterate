#!/usr/bin/env python3
"""Deterministic review-only audit for OI-EAW-P1-20261116-01 D002.

This script reads the frozen caegraph-data-30tick.zip only.  It does not
recompute any upstream feature and does not create a canonical P1 product.
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd

SCRIPT_VERSION = "d002-review-audit-v1"
MICRO_SOURCE_KEY = "9be1111ea7a79a9e604f49e65f24a6c0fa019f8f"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json_bytes(value) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        value = float(value)
        if value == int(value):
            return int(value)
        return value
    if isinstance(value, (pd.Timestamp, np.datetime64)):
        return str(pd.Timestamp(value))
    if pd.isna(value):
        return None
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("zip_path")
    parser.add_argument("output_json")
    args = parser.parse_args()

    zip_path = Path(args.zip_path)
    blob = zip_path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        names = archive.namelist()
        bad_crc = archive.testzip()
        prefix = "caegraph-review/data/"
        manifest_bytes = archive.read(prefix + "manifest.json")
        manifest = json.loads(manifest_bytes)
        assets = manifest["assets"]

        def read_csv_member(member: str, **kwargs):
            return pd.read_csv(io.BytesIO(archive.read(member)), **kwargs)

        def read_asset(key: str) -> pd.DataFrame:
            info = assets[key]
            member = prefix + info["file"]
            raw = archive.read(member)
            return pd.read_csv(
                io.BytesIO(raw),
                compression="gzip",
                index_col=0,
            )

        def evidence_keys(df_key: str):
            suffix = "/" + df_key
            start = f"evidence/{MICRO_SOURCE_KEY}/"
            return sorted(k for k in assets if k.startswith(start) and k.endswith(suffix))

        def frames_for(df_key: str):
            out = {}
            for key in evidence_keys(df_key):
                symbol = key.split("/")[-2]
                out[symbol] = read_asset(key)
            return out

        calendar_npz = np.load(io.BytesIO(archive.read(prefix + "calendar.npz")))
        starts = np.asarray(calendar_npz["starts"], dtype=np.int64)
        timestamps = np.asarray(calendar_npz["timestamps"], dtype=np.int64)
        calendar_size = int(calendar_npz["size"])

        def uti_to_ns(values):
            values = np.asarray(values, dtype=np.int64)
            indices = np.searchsorted(starts, values, side="right") - 1
            if np.any(indices < 0):
                raise ValueError("UTI precedes first calendar segment")
            return timestamps[indices] + (values - starts[indices]) * 500_000_000

        timespans = read_csv_member(prefix + "timespans.csv")
        included_ticks = read_csv_member(prefix + "included_tick_nodes.csv")

        evidence_df_keys = sorted(
            {
                str(item.get("df_key"))
                for item in manifest["evidence_features"]
                if item.get("df_key") is not None
            }
        )
        source_keys = sorted(
            {str(item.get("source_key")) for item in manifest["evidence_features"]}
        )

        attacks = frames_for("attack_segments")
        attack_by_symbol = {}
        attack_total = 0
        mismatch_total = 0
        cross_session_cases = []
        for symbol in sorted(attacks):
            frame = attacks[symbol]
            attack_total += int(frame.shape[0])
            actual_ns = pd.to_datetime(frame["business_end_ts"]).astype("int64").to_numpy()
            start_ns = uti_to_ns(frame["start_uti"].to_numpy())
            end_ns = uti_to_ns(frame["business_end_uti"].to_numpy())
            delta_seconds = (actual_ns - end_ns) / 1_000_000_000.0
            mismatch = delta_seconds != 0.0
            mismatch_total += int(np.count_nonzero(mismatch))
            delta_hist = collections.Counter(float(v) for v in delta_seconds)
            cross_mask = delta_seconds == -21600.5
            for index in np.flatnonzero(cross_mask):
                row = frame.iloc[int(index)]
                cross_session_cases.append(
                    {
                        "symbol": symbol,
                        "segment_id": int(row["segment_id"]),
                        "start_uti": int(row["start_uti"]),
                        "business_end_uti": int(row["business_end_uti"]),
                        "stored_business_end_ts": str(row["business_end_ts"]),
                        "calendar_start_ts": str(pd.to_datetime(start_ns[index])),
                        "calendar_business_end_ts": str(pd.to_datetime(end_ns[index])),
                        "close_reason_code": int(row["close_reason_code"]),
                    }
                )
            attack_by_symbol[symbol] = {
                "rows": int(frame.shape[0]),
                "columns": list(frame.columns),
                "plot_uti_equals_uti_equals_business_end_uti": bool(
                    (
                        (frame["plot_uti"].to_numpy() == frame["uti"].to_numpy())
                        & (
                            frame["uti"].to_numpy()
                            == frame["business_end_uti"].to_numpy()
                        )
                    ).all()
                ),
                "stored_ts_equals_calendar_start_uti": int(
                    np.count_nonzero(actual_ns == start_ns)
                ),
                "stored_ts_equals_calendar_business_end_uti": int(
                    np.count_nonzero(actual_ns == end_ns)
                ),
                "other_timestamp_binding": int(
                    np.count_nonzero((actual_ns != start_ns) & (actual_ns != end_ns))
                ),
                "business_end_timestamp_mismatch_rows": int(
                    np.count_nonzero(mismatch)
                ),
                "delta_seconds_histogram": {
                    str(k): int(v) for k, v in sorted(delta_hist.items())
                },
                "one_tick_start_bound_rows": int(
                    np.count_nonzero(
                        (actual_ns == start_ns)
                        & (
                            frame["business_end_uti"].to_numpy()
                            - frame["start_uti"].to_numpy()
                            == 1
                        )
                    )
                ),
                "availability_code_histogram": {
                    str(int(k)): int(v)
                    for k, v in frame["availability_code"]
                    .value_counts()
                    .sort_index()
                    .items()
                },
                "close_reason_code_histogram": {
                    str(int(k)): int(v)
                    for k, v in frame["close_reason_code"]
                    .value_counts()
                    .sort_index()
                    .items()
                },
            }

        f4_tactical = frames_for("f4_tactical")
        f4_structural = frames_for("f4_structural")
        f4_by_symbol = {}
        union_digest = hashlib.sha256()
        tactical_total = structural_total = overlap_total = grade_diff_total = 0
        union_total = 0
        for symbol in sorted(f4_tactical):
            tactical = f4_tactical[symbol].copy()
            structural = f4_structural[symbol].copy()
            key = ["uti", "side_code"]
            tactical_total += int(tactical.shape[0])
            structural_total += int(structural.shape[0])
            if tactical.duplicated(key).any() or structural.duplicated(key).any():
                raise ValueError(f"{symbol}: duplicate F4 lane key")
            merged = tactical.merge(
                structural,
                on=key,
                how="outer",
                suffixes=("_tactical", "_structural"),
                indicator="merge_state",
                sort=True,
            )
            overlap = merged["merge_state"].eq("both")
            structural_only = merged["merge_state"].eq("right_only")
            grade_diff = overlap & (
                merged["grade_tactical"] != merged["grade_structural"]
            )
            amount_equal = overlap & (
                merged["deal_amt_tactical"] == merged["deal_amt_structural"]
            )
            volume_equal = overlap & (
                merged["directional_hit_volume_proxy_tactical"]
                == merged["directional_hit_volume_proxy_structural"]
            )
            ts_equal = overlap & (merged["ts_tactical"] == merged["ts_structural"])
            overlap_total += int(overlap.sum())
            grade_diff_total += int(grade_diff.sum())
            union_total += int(merged.shape[0])

            for row in merged.sort_values(key).itertuples(index=False):
                rec = {
                    "symbol": symbol,
                    "uti": int(row.uti),
                    "side_code": int(row.side_code),
                    "lane_mask": 3 if row.merge_state == "both" else (
                        1 if row.merge_state == "left_only" else 2
                    ),
                    "tactical_grade": (
                        None
                        if pd.isna(row.grade_tactical)
                        else int(row.grade_tactical)
                    ),
                    "structural_grade": (
                        None
                        if pd.isna(row.grade_structural)
                        else int(row.grade_structural)
                    ),
                    "deal_amt": float(
                        row.deal_amt_tactical
                        if not pd.isna(row.deal_amt_tactical)
                        else row.deal_amt_structural
                    ),
                    "directional_hit_volume_proxy": float(
                        row.directional_hit_volume_proxy_tactical
                        if not pd.isna(row.directional_hit_volume_proxy_tactical)
                        else row.directional_hit_volume_proxy_structural
                    ),
                    "ts": str(
                        row.ts_tactical
                        if not pd.isna(row.ts_tactical)
                        else row.ts_structural
                    ),
                }
                union_digest.update(canonical_json_bytes(rec))

            f4_by_symbol[symbol] = {
                "tactical_rows": int(tactical.shape[0]),
                "structural_rows": int(structural.shape[0]),
                "tactical_duplicate_keys": int(tactical.duplicated(key).sum()),
                "structural_duplicate_keys": int(structural.duplicated(key).sum()),
                "overlap_keys": int(overlap.sum()),
                "structural_only_keys": int(structural_only.sum()),
                "review_only_union_keys": int(merged.shape[0]),
                "overlap_amount_equal": int(amount_equal.sum()),
                "overlap_volume_equal": int(volume_equal.sum()),
                "overlap_ts_equal": int(ts_equal.sum()),
                "overlap_grade_diff": int(grade_diff.sum()),
            }

        absorbs = frames_for("absorb_events")
        absorb_by_symbol = {}
        resolve_only_total = multi_milestone_rows_total = 0
        zero_wall_rows_total = zero_wall_tracks_total = 0
        for symbol in sorted(absorbs):
            frame = absorbs[symbol]
            event_sets = frame.groupby("track_id")["event_type_code"].agg(
                lambda values: set(int(v) for v in values)
            )
            resolve_only_ids = event_sets[
                event_sets.apply(lambda values: 13 in values and 11 not in values)
            ].index
            resolve_only = frame[
                frame["track_id"].isin(resolve_only_ids)
                & frame["event_type_code"].eq(13)
            ]
            milestones = frame[frame["event_type_code"].eq(12)]
            milestone_groups = milestones.groupby(["track_id", "uti"]).size()
            multi_groups = milestone_groups[milestone_groups > 1]
            zero_wall = frame[frame["wall_local_no"].eq(0)]
            resolve_only_total += int(len(resolve_only_ids))
            multi_milestone_rows_total += int(multi_groups.sum())
            zero_wall_rows_total += int(zero_wall.shape[0])
            zero_wall_tracks_total += int(zero_wall["track_id"].nunique())
            absorb_by_symbol[symbol] = {
                "rows": int(frame.shape[0]),
                "columns": list(frame.columns),
                "event_type_code_histogram": {
                    str(int(k)): int(v)
                    for k, v in frame["event_type_code"]
                    .value_counts()
                    .sort_index()
                    .items()
                },
                "milestone_level_field_present": "level" in frame.columns,
                "milestone_rows": int(milestones.shape[0]),
                "same_track_uti_milestone_group_size_histogram": {
                    str(int(k)): int(v)
                    for k, v in milestone_groups.value_counts().sort_index().items()
                },
                "multi_milestone_groups": int(multi_groups.shape[0]),
                "multi_milestone_rows": int(multi_groups.sum()),
                "resolve_only_tracks": int(len(resolve_only_ids)),
                "resolve_only_reason_histogram": {
                    str(int(k)): int(v)
                    for k, v in resolve_only["resolved_type_code"]
                    .value_counts()
                    .sort_index()
                    .items()
                },
                "resolve_only_milestone_rows": int(
                    frame[
                        frame["track_id"].isin(resolve_only_ids)
                        & frame["event_type_code"].eq(12)
                    ].shape[0]
                ),
                "wall_local_no_zero_rows": int(zero_wall.shape[0]),
                "wall_local_no_zero_tracks": int(zero_wall["track_id"].nunique()),
                "wall_local_no_zero_event_type_histogram": {
                    str(int(k)): int(v)
                    for k, v in zero_wall["event_type_code"]
                    .value_counts()
                    .sort_index()
                    .items()
                },
                "occurrence_ordinal_max": int(frame["occurrence_ordinal"].max()),
            }

        direct_product_keys = {
            "attack_formation_evidence": [
                key for key in evidence_df_keys if "formation" in key
            ],
            "wall_relation_barrier": [
                key for key in evidence_df_keys if "barrier" in key
            ],
            "f3_active_flow": [
                key
                for key in evidence_df_keys
                if "f3" in key.lower() or "active_flow" in key.lower()
            ],
        }

        provenance_member_hits = sorted(
            name
            for name in names
            if any(
                token in name.lower()
                for token in (
                    "p1_receipt",
                    "provenance",
                    "source_run",
                    "run_manifest",
                    "revision",
                )
            )
        )

        result = {
            "schema": "oi-eaw-p1-d002-review-only-derivations/v1",
            "derivation_status": "NOT_CANONICAL_PRODUCT",
            "formal_evidence_judgment_performed": False,
            "script_version": SCRIPT_VERSION,
            "input": {
                "path_basename": zip_path.name,
                "bytes": len(blob),
                "sha256": sha256_bytes(blob),
                "zip_member_count": len(names),
                "zip_crc": "ALL_PASS" if bad_crc is None else f"FAIL:{bad_crc}",
                "manifest_sha256": sha256_bytes(manifest_bytes),
            },
            "provenance_inventory": {
                "archive_members_matching_receipt_or_run_provenance": provenance_member_hits,
                "manifest_top_level_fields": sorted(manifest.keys()),
                "manifest_source_keys": source_keys,
                "microstructure_source_key": MICRO_SOURCE_KEY,
                "evidence_df_keys": evidence_df_keys,
                "direct_product_key_search": direct_product_keys,
            },
            "scope": {
                "symbols": manifest["symbols"],
                "block": manifest["blk"],
                "calendar_name": manifest["calendar_name"],
                "calendar_size": calendar_size,
                "calendar_segments": int(len(starts)),
                "calendar_first": str(pd.to_datetime(timestamps[0])),
                "calendar_last": str(
                    pd.to_datetime(
                        timestamps[-1]
                        + (calendar_size - 1 - starts[-1]) * 500_000_000
                    )
                ),
                "data_scope": manifest["data_scope"],
                "big_nodes": timespans[timespans["level"].eq("big")][
                    [
                        "node_id",
                        "start_uti",
                        "end_uti",
                        "start_ts",
                        "end_ts",
                    ]
                ].to_dict("records"),
                "included_tick_node_count": int(included_ticks.shape[0]),
                "included_tick_first": str(included_ticks.iloc[0]["node_id"]),
                "included_tick_last": str(included_ticks.iloc[-1]["node_id"]),
            },
            "attack_time_audit": {
                "rows_total": attack_total,
                "business_end_timestamp_mismatch_rows": mismatch_total,
                "closed_at_fields_present": any(
                    "closed_at_uti" in frame.columns
                    or "closed_at_ts" in frame.columns
                    for frame in attacks.values()
                ),
                "by_symbol": attack_by_symbol,
                "session_boundary_cases": cross_session_cases,
            },
            "f4_review_only_union_audit": {
                "status": "NOT_CANONICAL_PRODUCT",
                "key": ["symbol", "uti", "side_code"],
                "tactical_rows_total": tactical_total,
                "structural_rows_total": structural_total,
                "overlap_keys_total": overlap_total,
                "review_only_union_keys_total": union_total,
                "overlap_grade_diff_total": grade_diff_total,
                "canonical_jsonl_digest_sha256": union_digest.hexdigest(),
                "by_symbol": f4_by_symbol,
            },
            "absorb_identity_audit": {
                "resolve_only_tracks_total": resolve_only_total,
                "multi_milestone_rows_total": multi_milestone_rows_total,
                "wall_local_no_zero_rows_total": zero_wall_rows_total,
                "wall_local_no_zero_tracks_total": zero_wall_tracks_total,
                "by_symbol": absorb_by_symbol,
            },
            "reproduction": {
                "command": "python D002_REVIEW_ONLY_AUDIT.py caegraph-data-30tick.zip D002_REVIEW_ONLY_DERIVATIONS.json",
                "notes": [
                    "Reads only the frozen ZIP.",
                    "Does not access the original run or recompute upstream features.",
                    "The F4 union exists only as an audit digest and must not be published as a producer product.",
                ],
            },
        }

    output_bytes = json.dumps(
        json_safe(result),
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
    ).encode("utf-8") + b"\n"
    Path(args.output_json).write_bytes(output_bytes)
    print(
        json.dumps(
            {
                "output": str(args.output_json),
                "bytes": len(output_bytes),
                "sha256": sha256_bytes(output_bytes),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
